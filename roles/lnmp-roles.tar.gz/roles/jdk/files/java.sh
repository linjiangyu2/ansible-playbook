export JAVA_HOME=/usr
